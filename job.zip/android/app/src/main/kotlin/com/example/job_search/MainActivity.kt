package com.example.job_search

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
