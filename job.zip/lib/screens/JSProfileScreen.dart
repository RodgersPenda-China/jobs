import 'package:flutter/material.dart';
import 'package:nb_utils/nb_utils.dart';
import 'package:job_search/components/JSCvComponent.dart';
import 'package:job_search/components/JSDrawerScreen.dart';
import 'package:job_search/model/JSPopularCompanyModel.dart';
import 'package:job_search/utils/JSColors.dart';
import 'package:job_search/utils/JSDataGenerator.dart';
import 'package:job_search/utils/JSWidget.dart';
import 'package:job_search/main.dart';

import '../components/JSReviewAndSaVeComponent.dart';

class JSProfileScreen extends StatefulWidget {
  const JSProfileScreen({Key? key}) : super(key: key);

  @override
  _JSProfileScreenState createState() => _JSProfileScreenState();
}

class _JSProfileScreenState extends State<JSProfileScreen> {
  GlobalKey<ScaffoldState> scaffoldKey = GlobalKey();
  List<JSPopularCompanyModel> reviewDraftList = getReviewDraftList();
  List<JSPopularCompanyModel> skillList = getSkillList();

  TabController? controller;

  @override
  void initState() {
    super.initState();
    init();
  }

  void init() async {
    //
  }

  @override
  void setState(fn) {
    if (mounted) super.setState(fn);
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        key: scaffoldKey,
        drawer: JSDrawerScreen(),
        appBar: jsAppBar(context, backWidget: true, homeAction: true, message: false, notifications: false, bottomSheet: true, callBack: () {
          setState(() {});
          scaffoldKey.currentState!.openDrawer();
        }),
        body: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            16.height,
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  decoration: boxDecorationWithRoundedCorners(
                    boxShape: BoxShape.circle,
                    border: Border.all(color: js_primaryColor, width: 4),
                    backgroundColor: context.scaffoldBackgroundColor,
                  ),
                  padding: EdgeInsets.all(24),
                  child: Text('RP', style: boldTextStyle(size: 22)),
                ),
                16.width,
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [Text('Rodgers Penda', style: boldTextStyle(size: 22)), IconButton(onPressed: () {}, icon: Icon(Icons.edit, color: js_primaryColor))],
                    ),
                    Row(
                      children: [
                        Icon(Icons.location_on, color: context.iconColor),
                        8.width,
                        Text('Ngombe Health City', style: boldTextStyle()),
                      ],
                    ),
                    Row(
                      children: [
                        Icon(Icons.person, color: context.iconColor),
                        8.width,
                        Text('Male', style: boldTextStyle()),
                      ],
                    ),
                  ],
                ).expand()
              ],
            ).paddingSymmetric(horizontal: 16, vertical: 16),
            TabBar(
              labelColor: appStore.isDarkModeOn ? white : black,
              unselectedLabelColor: gray,
              isScrollable: false,
              indicatorColor: js_primaryColor,
              tabs: [
                Tab(child: Text("CV", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16))),
                Tab(child: Text("About me", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16))),
              ],
              controller: controller,
            ),
            TabBarView(
              children: [
                Container(
                  padding: EdgeInsets.all(8),
                  margin: EdgeInsets.all(16),
                  decoration: boxDecorationWithRoundedCorners(
                    borderRadius: BorderRadius.circular(8),
                    backgroundColor: appStore.isDarkModeOn ? scaffoldDarkColor : js_backGroundColor,
                  ),
                  child: SingleChildScrollView(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "You can only Upload 3 cvs at a time.",
                          style: boldTextStyle(),
                          overflow: TextOverflow.ellipsis,
                          maxLines: 3,
                        ).paddingAll(8),
                        Divider(color: gray.withOpacity(0.4)),
                        Card (
                          margin: EdgeInsets.all(10),
                          shadowColor: Colors.blueGrey,
                          elevation: 10,
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: <Widget>[
                               ListTile(
                                leading: Icon (
                                    Icons.picture_as_pdf,
                                    color: Colors.red,
                                    size: 45
                                ),
                                title: Text(
                                  "Php.pdf",
                                  style: TextStyle(fontSize: 20),
                                ),
                                trailing: Icon (
                                    Icons.close,
                                    // color: Colors.red,
                                    size: 23
                                ),
                              ),
                            ],
                          ),
                        ),
                        Card (
                          margin: EdgeInsets.all(10),
                          shadowColor: Colors.blueGrey,
                          elevation: 10,
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: <Widget>[
                              ListTile(
                                leading: Image.network('https://cdn-icons-png.flaticon.com/512/2306/2306065.png'),
                                title: Text(
                                  "Marketing.docx",
                                  style: TextStyle(fontSize: 20),
                                ),
                                trailing: Icon (
                                    Icons.close,
                                    // color: Colors.red,
                                    size: 23
                                ),
                              ),
                            ],
                          ),
                        ),

                        24.height,
                        AppButton(
                          color: js_textColor,
                          width: context.width(),
                          margin: EdgeInsets.symmetric(horizontal: 8),
                          onTap: () {
                            //JSCompleteProfileFiveScreen().launch(context);
                          },
                          shapeBorder: RoundedRectangleBorder(borderRadius: BorderRadius.circular(40)),
                          child: Text("Upload", style: boldTextStyle(color: white)),
                        ),
                      ],
                    ),
                  ),
                ),
                Container(
                child: SingleChildScrollView(
                  child:  Container(
                    margin: EdgeInsets.all(8),
                    padding: EdgeInsets.all(16),
                    decoration: boxDecorationWithRoundedCorners(
                      borderRadius: BorderRadius.circular(8),
                      boxShadow: [
                        BoxShadow(spreadRadius: 0.6, blurRadius: 1, color: gray.withOpacity(0.5)),
                      ],
                      backgroundColor: context.scaffoldBackgroundColor,
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('Smit Jhon', style: boldTextStyle()),
                            16.width,
                            Icon(Icons.edit, color: js_primaryColor, size: 18),
                          ],
                        ),
                        24.height,
                        Text('London', style: boldTextStyle(size: 22)),
                        8.height,
                        Text('smit@gmail.com', style: primaryTextStyle()),
                        8.height,
                        Text('1234567890', style: primaryTextStyle(color: js_primaryColor, decoration: TextDecoration.underline)),
                        24.height,
                        Row(
                          children: [
                            Icon(Icons.add_circle_outline, color: js_primaryColor).onTap(() {
                              //
                            }),
                            16.width,
                            Text("UX Designer", style: boldTextStyle(color: js_primaryColor)),
                          ],
                        ),
                        24.height,
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text("Personal Detail", style: secondaryTextStyle(size: 18)),
                            IconButton(onPressed: () {}, icon: Icon(Icons.add_circle_outline, color: js_primaryColor)),
                          ],
                        ),
                        Divider(height: 0, color: gray.withOpacity(0.2)),
                        16.height,
                        Text("Smit Jhon", style: primaryTextStyle()),
                        8.height,
                        Text("London", style: secondaryTextStyle()),
                        24.height,
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text("Work Experience", style: secondaryTextStyle(size: 18)),
                            IconButton(onPressed: () {}, icon: Icon(Icons.add_circle_outline, color: js_primaryColor)),
                          ],
                        ),
                        Divider(height: 0, color: gray.withOpacity(0.2)),
                        8.height,
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text("UI/UX Designer", style: boldTextStyle()),
                            Row(
                              children: [
                                IconButton(onPressed: () {}, icon: Icon(Icons.edit, color: js_primaryColor)),
                                IconButton(onPressed: () {}, icon: Icon(Icons.delete, color: js_primaryColor)),
                              ],
                            ),
                          ],
                        ),
                        Text("Premier Inn -London", style: primaryTextStyle()),
                        8.height,
                        Text('August 2021 to present', style: secondaryTextStyle()),
                        8.height,
                        Text('This is my Description', style: primaryTextStyle()),
                        24.height,
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text("Education", style: secondaryTextStyle(size: 18)),
                            IconButton(onPressed: () {}, icon: Icon(Icons.add_circle_outline, color: js_primaryColor)),
                          ],
                        ),
                        Divider(height: 0, color: gray.withOpacity(0.2)),
                        8.height,
                        Text("BCA", style: boldTextStyle()),
                        8.height,
                        Text('August 2021', style: secondaryTextStyle()),
                        8.height,
                        Text('I am Completed BCA in 2021', style: primaryTextStyle()),
                        24.height,
                      ],
                    ),
                  ),
                )
                )
              ],
            ).expand(),
          ],
        ),
      ),
    );
  }
}
